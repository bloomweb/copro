-- phpMyAdmin SQL Dump
-- version 4.0.6deb1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 21-02-2014 a las 11:17:53
-- Versión del servidor: 5.5.35-0ubuntu0.13.10.2
-- Versión de PHP: 5.5.3-1ubuntu2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `bloomweb_copro`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `addresses`
--

CREATE TABLE IF NOT EXISTS `addresses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL DEFAULT 'default',
  `user_id` int(11) NOT NULL,
  `address` varchar(45) NOT NULL,
  `zip` varchar(45) DEFAULT NULL,
  `country_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `zone_id` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_addresses_countries_INDEX` (`country_id`),
  KEY `fk_addresses_cities_INDEX` (`city_id`),
  KEY `fk_addresses_users_INDEX` (`user_id`),
  KEY `fk_addresses_zones_INDEX` (`zone_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=29 ;

--
-- Volcado de datos para la tabla `addresses`
--

INSERT INTO `addresses` (`id`, `name`, `user_id`, `address`, `zip`, `country_id`, `city_id`, `zone_id`, `created`, `updated`) VALUES
(1, 'Casa', 8, 'Calle 12 # 85 - 115', '7600-1000', 1, 1, 0, '2012-02-28 02:11:46', '2012-02-28 02:11:46'),
(8, 'Hogar', 16, 'Calle 12 # 85 - 115', '7600-1000', 1, 1, 0, '2012-02-28 05:16:51', '2012-02-28 05:16:51'),
(9, 'default', 18, 'cra 3ra cn # 71 d 07', '0000', 1, 1, 1, '2012-03-13 21:56:17', '2012-03-13 21:56:17'),
(10, 'granada', 16, 'Calle 12 # 85 - 115', '76001000', 1, 1, 1, '2012-03-16 20:47:33', '2012-03-16 20:47:33'),
(11, 'default', 19, 'test', '76001000', 1, 2, 3, '2012-04-25 14:42:23', '2012-04-25 14:42:23'),
(12, 'default', 20, 'test', '76001000', 1, 2, 3, '2012-04-25 14:56:04', '2012-04-25 14:56:04'),
(13, 'default', 21, 'test', '76001000', 1, 2, 3, '2012-04-25 15:09:32', '2012-04-25 15:09:32'),
(14, 'default', 22, 'calle 23', '0000000', 1, 2, 3, '2012-04-25 21:37:19', '2012-04-25 21:37:19'),
(15, 'default', 27, 'Langackerstrasse 5', '8330', 1, 1, 1, '2012-05-02 09:50:28', '2012-05-02 09:50:28'),
(16, 'casa', 28, 'Av. 2BN No. 39-112', '', 1, 1, 1, '2012-05-02 21:23:26', '2012-05-23 10:31:23'),
(17, 'default', 29, 'calle 55A # 2EN-54', '', 1, 1, 5, '2012-05-05 14:36:28', '2012-05-05 14:36:28'),
(18, 'default', 30, 'Calle 44 No. 25-36', '', 1, 1, 6, '2012-05-05 14:44:07', '2012-05-05 14:44:07'),
(19, 'default', 34, 'Av 3 oeste No 12 - 94 Apto 2', '', 1, 1, 11, '2012-05-20 15:46:55', '2012-05-20 15:46:55'),
(20, 'default', 35, 'carrera 1 No, 2 A 44 oeste', '00591', 1, 1, 1, '2012-05-20 16:48:56', '2012-05-20 16:48:56'),
(21, 'default', 36, 'calle 56 5-22', '472', 1, 2, 12, '2012-05-20 17:23:01', '2012-05-20 17:23:01'),
(22, 'default', 37, 'Av. 2BN No. 39-112', '', 1, 1, 1, '2012-05-23 10:54:39', '2012-05-23 10:54:39'),
(23, 'default', 1, 'test', '76001000', 1, 1, 1, '2012-05-23 11:09:14', '2012-05-23 11:09:14'),
(24, 'default', 1, 'test', '76001000', 1, 1, 1, '2012-05-23 11:13:42', '2012-05-23 11:13:42'),
(25, 'DirecciÃ³n de Registro', 38, 'calle 13', 'NA', 1, 1, 2, '2012-05-29 20:27:58', '2012-05-29 20:27:58'),
(26, 'prueba', 38, 'calle 15', NULL, 1, 2, 4, '2012-05-29 20:47:40', '2012-05-29 20:47:40'),
(27, 'DirecciÃ³n de Registro', 39, 'calle test', '76001000', 1, 1, 2, '2012-07-09 00:55:27', '2012-07-09 00:55:27'),
(28, 'DirecciÃ³n de Registro', 41, 'calle test', '76001000', 1, 1, 7, '2012-07-09 01:08:33', '2012-07-09 01:08:33');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cities`
--

CREATE TABLE IF NOT EXISTS `cities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL,
  `is_present` tinyint(1) DEFAULT NULL,
  `code` varchar(45) DEFAULT NULL,
  `lat` varchar(45) DEFAULT NULL,
  `long` varchar(45) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cities_countries_INDEX` (`country_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `cities`
--

INSERT INTO `cities` (`id`, `country_id`, `name`, `description`, `image`, `is_present`, `code`, `lat`, `long`, `created`, `updated`) VALUES
(1, 1, 'Cali', 'Santiago De Cali, Valle Del Cauca', 'colombia-cali.jpg', 1, '76001000', NULL, NULL, '2012-02-24 13:41:08', '2012-04-30 22:12:24'),
(2, 1, 'BogotÃ¡', 'Santa FÃ© De BogotÃ¡', 'colombia-bogota.jpg', 1, '11001000', NULL, NULL, '2012-02-24 13:47:43', '2012-02-24 13:47:43');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) DEFAULT NULL,
  `comment` text,
  `model` varchar(45) DEFAULT NULL,
  `foreign_key` varchar(45) DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `alias` varchar(45) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_comments_users_INDEX` (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `config`
--

CREATE TABLE IF NOT EXISTS `config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `score_by_registering` int(11) NOT NULL DEFAULT '0',
  `score_by_invitations` int(11) NOT NULL DEFAULT '0',
  `score_for_buying` int(11) NOT NULL DEFAULT '0',
  `max_score_by_invitations` int(11) NOT NULL DEFAULT '0',
  `is_newsletter_active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `config`
--

INSERT INTO `config` (`id`, `score_by_registering`, `score_by_invitations`, `score_for_buying`, `max_score_by_invitations`, `is_newsletter_active`) VALUES
(1, 500, 300, 30, 5000, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL,
  `language` varchar(45) DEFAULT NULL,
  `is_present` tinyint(1) DEFAULT NULL,
  `code` varchar(45) DEFAULT NULL,
  `money_symbol` varchar(10) DEFAULT NULL,
  `price_ranges` text,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `countries`
--

INSERT INTO `countries` (`id`, `name`, `description`, `image`, `language`, `is_present`, `code`, `money_symbol`, `price_ranges`, `created`, `updated`) VALUES
(1, 'Colombia', 'Colombia', 'colombia.jpg', 'ES', 1, '57', '$', '0-10000:10001-20000:20001-30000:30001-40000:40001-50000:50001-100000', '2012-02-24 13:38:57', '2012-03-15 08:10:47'),
(2, 'Estados Unidos', 'EEUU De America', 'EEUU.jpg', 'EN', 0, '00', NULL, NULL, '2012-02-25 00:44:37', '2012-02-25 00:44:37');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cuisines`
--

CREATE TABLE IF NOT EXISTS `cuisines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL,
  `slug` varchar(50) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Volcado de datos para la tabla `cuisines`
--

INSERT INTO `cuisines` (`id`, `name`, `description`, `image`, `slug`, `created`, `updated`) VALUES
(1, 'Italiana', 'Comida Italiana', 'cuisines-italiana.jpg', 'italiana', '2012-02-24 15:53:35', '2012-02-24 15:53:35'),
(2, 'Mexicana', 'Comida mexicana', 'cuisines-mexicana.jpg', 'mexicana', '2012-02-24 15:58:16', '2012-02-24 15:58:16'),
(3, 'Americana', 'Comida americana', 'cuisines-americana.jpg', 'americana', '2012-02-24 15:59:23', '2012-02-24 15:59:23'),
(4, 'Francesa', 'Comida francesa', 'cuisines-francesa.jpg', 'francesa', '2012-02-24 16:02:35', '2012-02-24 16:02:35'),
(5, 'Peruana', 'Comida peruana', 'cuisines-peruana.jpg', 'peruana', '2012-02-24 16:03:19', '2012-02-24 16:03:19'),
(6, 'Argentina', 'Comida argentina', 'cuisines-argentina.jpg', 'argentina', '2012-02-24 16:05:46', '2012-02-24 16:05:46');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cuisines_deals`
--

CREATE TABLE IF NOT EXISTS `cuisines_deals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cuisine_id` int(11) NOT NULL,
  `deal_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cuisine_deal` (`cuisine_id`,`deal_id`),
  KEY `fk_cuisines_deals_cuisines_INDEX` (`cuisine_id`),
  KEY `fk_cuisines_deals_deals_INDEX` (`deal_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=33 ;

--
-- Volcado de datos para la tabla `cuisines_deals`
--

INSERT INTO `cuisines_deals` (`id`, `cuisine_id`, `deal_id`) VALUES
(26, 1, 9),
(28, 1, 10),
(30, 1, 11),
(31, 2, 11),
(27, 3, 9),
(29, 3, 10),
(32, 3, 11);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `deals`
--

CREATE TABLE IF NOT EXISTS `deals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `restaurant_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` text,
  `conditions` text,
  `image` varchar(255) DEFAULT NULL,
  `image_large` varchar(255) DEFAULT NULL,
  `amount` int(11) NOT NULL DEFAULT '0',
  `price` double NOT NULL DEFAULT '0',
  `normal_price` double NOT NULL DEFAULT '0',
  `max_buys` int(11) NOT NULL DEFAULT '0',
  `expires` datetime DEFAULT NULL,
  `is_promoted` tinyint(1) NOT NULL DEFAULT '0',
  `visits` int(11) NOT NULL DEFAULT '0',
  `slug` varchar(50) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_deals_restaurants_INDEX` (`restaurant_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Volcado de datos para la tabla `deals`
--

INSERT INTO `deals` (`id`, `restaurant_id`, `name`, `description`, `conditions`, `image`, `image_large`, `amount`, `price`, `normal_price`, `max_buys`, `expires`, `is_promoted`, `visits`, `slug`, `created`, `updated`) VALUES
(1, 1, 'Churrasco', '<p>\r\n	Delicioso churrasco argentino acompa&ntilde;ado de papa gratinada, maduro, ensalada y gaseosa.</p>\r\n', '<p>\r\n	Desde la Cra 5 hasta la calle 100 y desde la Cra. 2 hasta la calle 12</p>\r\n', 'restaurante_asados_la_80-churrasco_350_grs_aprox (2).jpg', '', 89, 11500, 17000, 100, '2012-05-31 23:13:00', 0, 46, 'churrasco', '2012-04-30 22:16:26', '2012-05-16 20:22:39'),
(2, 2, 'Lasagna 2x1', '<p>\r\n	Espectacular Lasagna a la Bolo&ntilde;esa 2X1, acompa&ntilde;ada de pan frances.</p>\r\n', '<p>\r\n	Pidela todos los dias en los horarios que el restaurante se encuentra abierto.</p>\r\n', 'lasagnajpg11111 (1).jpg', 'lasagna (2).jpg', 95, 10000, 20000, 50, '2012-05-31 17:22:00', 1, 50, 'lasagna-2x1', '2012-05-01 17:32:41', '2012-05-09 21:50:04'),
(3, 3, 'Tacos paga 4 LLeva 6', '<p>\r\n	La buena cocina llega a tu casa. Tacos mexicanos Paga 4 lleva 6</p>\r\n', '<p>\r\n	Valido todos los dias en los horacion de atencion al publico</p>\r\n', 'comida-mexicana11111 (1).jpg', 'comida-mexicana222222 (6).jpg', 30, 13200, 17500, 30, '2012-05-31 18:02:00', 1, 39, 'tacos-paga-4-lleva-6', '2012-05-01 18:07:24', '2012-05-03 11:29:44'),
(4, 4, 'Hamburguesa  + Gaseosa  + Papas', '<p>\r\n	Disfruta de una delicosa Hamburguesa doble queso acompa&ntilde;ada de papas y gaseosa.</p>\r\n', '<p>\r\n	Abierto todos los dias de 10 am a 11 pm</p>\r\n', 'Aumenta-la-depresiÃ³n-con-la-comida-rÃ¡pida-y-la-bollerÃ­a11111111 (1).jpg', '', 48, 5000, 8000, 0, '2012-05-31 18:37:00', 0, 21, 'hamburguesa--mas-gaseosa--mas-papas', '2012-05-01 18:41:55', '2012-05-06 19:43:05'),
(6, 5, 'Bandeja Paisa', '<p>\r\n	Deliciosa Bandeja Paisa, acompa&ntilde;ada de maduro, huevo, arepa, chicharron y aguacate</p>\r\n', '<p>\r\n	Atendemos desde la calle 87 con carrera 15</p>\r\n', 'bandeja_paisa.jpg', '', 0, 5000, 9500, 0, '2012-05-31 13:42:00', 0, 10, 'bandeja-paisa', '2012-05-06 13:46:43', '2012-05-06 13:56:20'),
(7, 6, 'Ajiaco', '<p>\r\n	Autentico Ajiaco Bogotano, acompa&ntilde;ado de arroz, aguacate y mazorca. Disfruta de este delicioso plato en el sur de la ciudad</p>\r\n', '<p>\r\n	Promocion valida de Lunes a Jueves.</p>\r\n', 'ajiaco.jpg', '', 0, 6000, 12000, 0, '2012-05-31 14:22:00', 0, 6, 'ajiaco', '2012-05-06 14:26:32', '2012-05-06 14:30:37'),
(8, 7, 'Patacones con Carne', '<p>\r\n	Patacones con carne acompa&ntilde;ado con jugo de Lulo</p>\r\n', '<p>\r\n	Promocion valida todos los dias en los horarios de atencion del restaurante</p>\r\n', 'pataconconcarne.jpg', '', 0, 3000, 7000, 0, '2012-05-31 14:40:00', 0, 7, 'patacones-con-carne', '2012-05-06 14:42:19', '2012-05-06 14:42:19'),
(9, 1, 'prueba', '<p>\r\n	asdfasdfasdf</p>\r\n', NULL, 'Koala.jpg', '', 5, 5555, 55555, 0, '2012-07-29 22:04:00', 0, 0, 'prueba', '2012-05-29 22:05:29', '2012-05-29 22:05:29'),
(10, 1, 'otra prueba', '<p>\r\n	asdfasdfasdf</p>\r\n', 'eeee', 'Penguins.jpg', '', 5, 5555, 55555, 0, '2012-07-29 22:04:00', 0, 1, 'otra-prueba', '2012-05-29 22:07:05', '2012-05-29 22:07:05'),
(11, 1, 'prueba fecha', '<p>\r\n	la descripcion</p>\r\n', NULL, 'Chrysanthemum.jpg', '', 5, 1000, 1000, 0, '2012-06-30 10:59:00', 0, 1, 'prueba-fecha', '2012-05-31 11:00:05', '2012-05-31 11:00:05');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `i18n`
--

CREATE TABLE IF NOT EXISTS `i18n` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `locale` varchar(6) NOT NULL,
  `model` varchar(255) NOT NULL,
  `foreign_key` int(10) NOT NULL,
  `field` varchar(255) NOT NULL,
  `content` text,
  PRIMARY KEY (`id`),
  KEY `locale` (`locale`),
  KEY `model` (`model`),
  KEY `row_id` (`foreign_key`),
  KEY `field` (`field`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=211 ;

--
-- Volcado de datos para la tabla `i18n`
--

INSERT INTO `i18n` (`id`, `locale`, `model`, `foreign_key`, `field`, `content`) VALUES
(1, 'spa', 'Country', 1, 'name', 'Colombia'),
(2, 'spa', 'Country', 1, 'description', 'Colombia'),
(3, 'eng', 'Country', 1, 'name', 'Colombia'),
(4, 'eng', 'Country', 1, 'description', 'Colombia'),
(5, 'spa', 'City', 1, 'name', 'Cali'),
(6, 'spa', 'City', 1, 'description', 'Santiago De Cali, Valle Del Cauca'),
(7, 'eng', 'City', 1, 'name', 'Cali'),
(8, 'eng', 'City', 1, 'description', 'Santiago De Cali, Valle Del Cauca'),
(9, 'spa', 'City', 2, 'name', 'BogotÃ¡'),
(10, 'spa', 'City', 2, 'description', 'Santa FÃ© De BogotÃ¡'),
(11, 'eng', 'City', 2, 'name', 'BogotÃ¡'),
(12, 'eng', 'City', 2, 'description', 'Santa FÃ© De BogotÃ¡'),
(13, 'spa', 'Zone', 1, 'name', 'Granada'),
(14, 'spa', 'Zone', 1, 'description', 'Barrio Granada'),
(15, 'eng', 'Zone', 1, 'name', 'Granada'),
(16, 'eng', 'Zone', 1, 'description', 'Barrio Granada'),
(17, 'spa', 'Zone', 2, 'name', 'San Antonio'),
(18, 'spa', 'Zone', 2, 'description', 'Barrio San Antonio'),
(19, 'eng', 'Zone', 2, 'name', 'San Antonio'),
(20, 'eng', 'Zone', 2, 'description', 'Barrio San Antonio'),
(21, 'spa', 'Restaurant', 2, 'name', 'Picola Italia'),
(22, 'spa', 'Restaurant', 2, 'description', ''),
(23, 'spa', 'Restaurant', 2, 'address', 'Av. 2BN # 39-112'),
(24, 'spa', 'Restaurant', 2, 'schedule', 'Lunes a Viernes de 2 pm a 10 pm'),
(25, 'eng', 'Restaurant', 2, 'name', 'Picola Italia'),
(26, 'eng', 'Restaurant', 2, 'description', ''),
(27, 'eng', 'Restaurant', 2, 'address', 'Av. 2BN # 39-112'),
(28, 'eng', 'Restaurant', 2, 'schedule', 'Lunes a Viernes de 2 pm a 10 pm'),
(29, 'spa', 'Cuisine', 1, 'name', 'Italiana'),
(30, 'spa', 'Cuisine', 1, 'description', 'Comida Italiana'),
(31, 'eng', 'Cuisine', 1, 'name', 'Italiana'),
(32, 'eng', 'Cuisine', 1, 'description', 'Comida Italiana'),
(33, 'spa', 'Cuisine', 2, 'name', 'Mexicana'),
(34, 'spa', 'Cuisine', 2, 'description', 'Comida mexicana'),
(35, 'eng', 'Cuisine', 2, 'name', 'Mexicana'),
(36, 'eng', 'Cuisine', 2, 'description', 'Comida mexicana'),
(37, 'spa', 'Cuisine', 3, 'name', 'Americana'),
(38, 'spa', 'Cuisine', 3, 'description', 'Comida americana'),
(39, 'eng', 'Cuisine', 3, 'name', 'Americana'),
(40, 'eng', 'Cuisine', 3, 'description', 'Comida americana'),
(41, 'spa', 'Cuisine', 4, 'name', 'Francesa'),
(42, 'spa', 'Cuisine', 4, 'description', 'Comida francesa'),
(43, 'eng', 'Cuisine', 4, 'name', 'Francesa'),
(44, 'eng', 'Cuisine', 4, 'description', 'Comida francesa'),
(45, 'spa', 'Cuisine', 5, 'name', 'Peruana'),
(46, 'spa', 'Cuisine', 5, 'description', 'Comida peruana'),
(47, 'eng', 'Cuisine', 5, 'name', 'Peruana'),
(48, 'eng', 'Cuisine', 5, 'description', 'Comida peruana'),
(49, 'spa', 'Cuisine', 6, 'name', 'Argentina'),
(50, 'spa', 'Cuisine', 6, 'description', 'Comida argentina'),
(51, 'eng', 'Cuisine', 6, 'name', 'Argentina'),
(52, 'eng', 'Cuisine', 6, 'description', 'Comida argentina'),
(53, 'spa', 'Restaurant', 3, 'name', 'La Buena Onda'),
(54, 'spa', 'Restaurant', 3, 'description', ''),
(55, 'spa', 'Restaurant', 3, 'address', 'calle 8 No. 35-96'),
(56, 'spa', 'Restaurant', 3, 'schedule', 'Martes a Domingo de 11am a 1 am'),
(57, 'eng', 'Restaurant', 3, 'name', 'La Buena Onda'),
(58, 'eng', 'Restaurant', 3, 'description', ''),
(59, 'eng', 'Restaurant', 3, 'address', 'calle 8 No. 35-96'),
(60, 'eng', 'Restaurant', 3, 'schedule', ''),
(65, 'spa', 'Country', 2, 'name', 'Estados Unidos'),
(66, 'spa', 'Country', 2, 'description', 'EEUU De America'),
(67, 'eng', 'Country', 2, 'name', 'Estados Unidos'),
(68, 'eng', 'Country', 2, 'description', 'EEUU De America'),
(69, 'spa', 'Restaurant', 4, 'name', 'Fast Food'),
(70, 'spa', 'Restaurant', 4, 'description', ''),
(71, 'spa', 'Restaurant', 4, 'address', 'Calle 44N #3E-28 Norte Cali'),
(72, 'spa', 'Restaurant', 4, 'schedule', 'Miercoles a Domingo de 1 pm a 11 pm'),
(73, 'eng', 'Restaurant', 4, 'name', 'Fast Food'),
(74, 'eng', 'Restaurant', 4, 'description', ''),
(75, 'eng', 'Restaurant', 4, 'address', 'Calle 44N #3E-28 Norte Cali'),
(76, 'eng', 'Restaurant', 4, 'schedule', ''),
(77, 'spa', 'Zone', 3, 'name', 'Parque de la 93'),
(78, 'spa', 'Zone', 3, 'description', 'Zona de rumba y restaurantes'),
(79, 'eng', 'Zone', 3, 'name', 'Parque de la 93'),
(80, 'eng', 'Zone', 3, 'description', 'Zona de rumba y restaurantes'),
(81, 'spa', 'Restaurant', 5, 'name', 'Casa Majagua'),
(82, 'spa', 'Restaurant', 5, 'description', ''),
(83, 'spa', 'Restaurant', 5, 'address', 'Cra. 10 No. 65-78'),
(84, 'spa', 'Restaurant', 5, 'schedule', 'de Lunes a Vienes de 10am a 11pm'),
(85, 'eng', 'Restaurant', 5, 'name', 'Casa Majagua'),
(86, 'eng', 'Restaurant', 5, 'description', ''),
(87, 'eng', 'Restaurant', 5, 'address', 'Cra. 10 No. 65-78'),
(88, 'eng', 'Restaurant', 5, 'schedule', 'de Lunes a Vienes de 10am a 11pm'),
(89, 'spa', 'Restaurant', 6, 'name', 'Los Arrieros del Sur'),
(90, 'spa', 'Restaurant', 6, 'description', ''),
(91, 'spa', 'Restaurant', 6, 'address', 'Calle 5 No. 36-56'),
(92, 'spa', 'Restaurant', 6, 'schedule', 'De Martes a Sabado de 10am a 11pm'),
(93, 'eng', 'Restaurant', 6, 'name', 'Los Arrieros del Sur'),
(94, 'eng', 'Restaurant', 6, 'description', ''),
(95, 'eng', 'Restaurant', 6, 'address', 'Calle 5 No. 36-56'),
(96, 'eng', 'Restaurant', 6, 'schedule', ''),
(97, 'spa', 'Restaurant', 7, 'name', 'Pataconia'),
(98, 'spa', 'Restaurant', 7, 'description', ''),
(99, 'spa', 'Restaurant', 7, 'address', 'Av. 2BN # 39-112'),
(100, 'spa', 'Restaurant', 7, 'schedule', 'De Lunes a Viernes de 10am a 1am'),
(101, 'eng', 'Restaurant', 7, 'name', 'Pataconia'),
(102, 'eng', 'Restaurant', 7, 'description', ''),
(103, 'eng', 'Restaurant', 7, 'address', 'Av. 2BN # 39-112'),
(104, 'eng', 'Restaurant', 7, 'schedule', 'De Lunes a Viernes de 10am a 1am'),
(105, 'spa', 'Deal', 1, 'name', 'Churrasco'),
(106, 'spa', 'Deal', 1, 'description', '<p>\r\n	Delicioso churrasco argentino acompa&ntilde;ado de papa gratinada, maduro, ensalada y gaseosa.</p>\r\n'),
(107, 'spa', 'Deal', 1, 'conditions', '<p>\r\n	Desde la Cra 5 hasta la calle 100 y desde la Cra. 2 hasta la calle 12</p>\r\n'),
(108, 'eng', 'Deal', 1, 'name', 'Churrasco'),
(109, 'eng', 'Deal', 1, 'description', '<p>\r\n	Delicioso churrasco argentino acompa&ntilde;ado de papa gratinada, maduro, ensalada y gaseosa.</p>\r\n'),
(110, 'eng', 'Deal', 1, 'conditions', '<p>\r\n	Valido solo de lunes a jueves.</p>\r\n'),
(111, 'spa', 'Deal', 2, 'name', 'Lasagna 2x1'),
(112, 'spa', 'Deal', 2, 'description', '<p>\r\n	Espectacular Lasagna a la Bolo&ntilde;esa 2X1, acompa&ntilde;ada de pan frances.</p>\r\n'),
(113, 'spa', 'Deal', 2, 'conditions', '<p>\r\n	Pidela todos los dias en los horarios que el restaurante se encuentra abierto.</p>\r\n'),
(114, 'eng', 'Deal', 2, 'name', 'Lasagna 2x1'),
(115, 'eng', 'Deal', 2, 'description', '<p>\r\n	Espectacular Lasagna a la Bolo&ntilde;esa 2X1, acompa&ntilde;ada de pan frances.</p>\r\n'),
(116, 'eng', 'Deal', 2, 'conditions', '<p>\r\n	Pidela todos los dias en los horarios que el restaurante se encuentra abierto.</p>\r\n'),
(117, 'spa', 'Deal', 3, 'name', 'Tacos paga 4 LLeva 6'),
(118, 'spa', 'Deal', 3, 'description', '<p>\r\n	La buena cocina llega a tu casa. Tacos mexicanos Paga 4 lleva 6</p>\r\n'),
(119, 'spa', 'Deal', 3, 'conditions', '<p>\r\n	Valido todos los dias en los horacion de atencion al publico</p>\r\n'),
(120, 'eng', 'Deal', 3, 'name', 'Tacos paga 4 LLeva 6'),
(121, 'eng', 'Deal', 3, 'description', '<p>\r\n	La buena cocina llega a tu casa. Tacos mexicanos Paga 4 lleva 6</p>\r\n'),
(122, 'eng', 'Deal', 3, 'conditions', '<p>\r\n	Valido todos los dias en los horacion de atencion al publico</p>\r\n'),
(123, 'spa', 'Zone', 4, 'name', 'La Macarena'),
(124, 'spa', 'Zone', 4, 'description', 'Una de las zonas mÃ¡s bohemias de BogotÃ¡, allÃ­ estÃ¡n ubicados varios restaurantes de comida internacional con gran tradiciÃ³n en la ciudad, que permiten disfrutar de momentos agradables en compaÃ±Ã­a de su pareja, amigos o familiares.'),
(125, 'eng', 'Zone', 4, 'name', 'La Macarena'),
(126, 'eng', 'Zone', 4, 'description', 'Una de las zonas mÃ¡s bohemias de BogotÃ¡, allÃ­ estÃ¡n ubicados varios restaurantes de comida internacional con gran tradiciÃ³n en la ciudad, que permiten disfrutar de momentos agradables en compaÃ±Ã­a de su pareja, amigos o familiares.'),
(127, 'spa', 'Restaurant', 8, 'name', 'prueba'),
(128, 'spa', 'Restaurant', 8, 'description', 'prueba'),
(129, 'spa', 'Restaurant', 8, 'address', 'PRUEBA'),
(130, 'spa', 'Restaurant', 8, 'schedule', 'prueba'),
(131, 'eng', 'Restaurant', 8, 'name', 'prueba'),
(132, 'eng', 'Restaurant', 8, 'description', 'prueba'),
(133, 'eng', 'Restaurant', 8, 'address', 'PRUEBA'),
(134, 'eng', 'Restaurant', 8, 'schedule', 'prueba'),
(135, 'spa', 'Restaurant', 9, 'name', 'prueba'),
(136, 'spa', 'Restaurant', 9, 'description', 'asdf'),
(137, 'spa', 'Restaurant', 9, 'address', '4444'),
(138, 'spa', 'Restaurant', 9, 'schedule', 'asdf'),
(139, 'eng', 'Restaurant', 9, 'name', 'prueba'),
(140, 'eng', 'Restaurant', 9, 'description', 'asdf'),
(141, 'eng', 'Restaurant', 9, 'address', '4444'),
(142, 'eng', 'Restaurant', 9, 'schedule', 'asdf'),
(143, 'spa', 'Restaurant', 1, 'name', 'La Vaca Argentina'),
(144, 'spa', 'Restaurant', 1, 'description', 'Restaurante Argentino en la zona rosa de la ciudad de Cali.'),
(145, 'spa', 'Restaurant', 1, 'address', 'Calle 44N #3E-28 Norte Cali'),
(146, 'spa', 'Restaurant', 1, 'schedule', 'De 11 am a 11 pm'),
(147, 'eng', 'Restaurant', 1, 'name', 'La Vaca Argentina'),
(148, 'eng', 'Restaurant', 1, 'description', 'Restaurante Argentino en la zona rosa de la ciudad de Cali.'),
(149, 'eng', 'Restaurant', 1, 'address', 'Calle 44N #3E-28 Norte Cali'),
(150, 'eng', 'Restaurant', 1, 'schedule', 'De 11 am a 11 pm'),
(151, 'spa', 'Deal', 4, 'name', 'Hamburguesa  + Gaseosa  + Papas'),
(152, 'spa', 'Deal', 4, 'description', '<p>\r\n	Disfruta de una delicosa Hamburguesa doble queso acompa&ntilde;ada de papas y gaseosa.</p>\r\n'),
(153, 'spa', 'Deal', 4, 'conditions', '<p>\r\n	Abierto todos los dias de 10 am a 11 pm</p>\r\n'),
(154, 'eng', 'Deal', 4, 'name', 'Hamburguesa + Gaseosa + Papas'),
(155, 'eng', 'Deal', 4, 'description', '<p>\r\n	Disfruta de una delicosa Hamburguesa doble queso acompa&ntilde;ada de papas y gaseosa.</p>\r\n'),
(156, 'eng', 'Deal', 4, 'conditions', '<p>\r\n	Abierto todos los dias de 10 am a 11 pm</p>\r\n'),
(157, 'spa', 'Deal', 5, 'name', 'Pizza Familiar'),
(158, 'spa', 'Deal', 5, 'description', '<p>\r\n	Super pizza familiar de piment&oacute;n con champi&ntilde;ones</p>\r\n'),
(159, 'spa', 'Deal', 5, 'conditions', '<p>\r\n	Abierto todos los dias de 11 am a 11 pm</p>\r\n'),
(160, 'eng', 'Deal', 5, 'name', 'Pizza Familiar'),
(161, 'eng', 'Deal', 5, 'description', '<p>\r\n	Super pizza familiar de piment&oacute;n con champi&ntilde;ones</p>\r\n'),
(162, 'eng', 'Deal', 5, 'conditions', '<p>\r\n	Abierto todos los dias de 11 am a 11 pm</p>\r\n'),
(163, 'spa', 'Zone', 5, 'name', 'Alamos'),
(164, 'eng', 'Zone', 5, 'name', 'Alamos'),
(165, 'spa', 'Zone', 6, 'name', 'Vipasa'),
(166, 'eng', 'Zone', 6, 'name', 'Vipasa'),
(167, 'spa', 'Zone', 7, 'name', 'Alamos'),
(168, 'spa', 'Zone', 7, 'description', ''),
(169, 'eng', 'Zone', 7, 'name', 'Alamos'),
(170, 'eng', 'Zone', 7, 'description', ''),
(171, 'spa', 'Zone', 8, 'name', 'Vipasa'),
(172, 'spa', 'Zone', 8, 'description', ''),
(173, 'eng', 'Zone', 8, 'name', 'Vipasa'),
(174, 'eng', 'Zone', 8, 'description', ''),
(175, 'spa', 'Zone', 9, 'name', 'La Merced'),
(176, 'spa', 'Zone', 9, 'description', ''),
(177, 'eng', 'Zone', 9, 'name', 'La Merced'),
(178, 'eng', 'Zone', 9, 'description', ''),
(179, 'spa', 'Zone', 10, 'name', 'La Flora'),
(180, 'spa', 'Zone', 10, 'description', ''),
(181, 'eng', 'Zone', 10, 'name', 'La Flora'),
(182, 'eng', 'Zone', 10, 'description', ''),
(183, 'spa', 'Deal', 6, 'name', 'Bandeja Paisa'),
(184, 'spa', 'Deal', 6, 'description', '<p>\r\n	Deliciosa Bandeja Paisa, acompa&ntilde;ada de maduro, huevo, arepa, chicharron y aguacate</p>\r\n'),
(185, 'spa', 'Deal', 6, 'conditions', '<p>\r\n	Atendemos desde la calle 87 con carrera 15</p>\r\n'),
(186, 'eng', 'Deal', 6, 'name', 'Bandeja Paisa'),
(187, 'eng', 'Deal', 6, 'description', '<p>\r\n	Restaurante de comida tipica colombiana</p>\r\n'),
(188, 'eng', 'Deal', 6, 'conditions', '<p>\r\n	Atendemos desde la calle 87 con carrera 15</p>\r\n'),
(189, 'spa', 'Deal', 7, 'name', 'Ajiaco'),
(190, 'spa', 'Deal', 7, 'description', '<p>\r\n	Autentico Ajiaco Bogotano, acompa&ntilde;ado de arroz, aguacate y mazorca. Disfruta de este delicioso plato en el sur de la ciudad</p>\r\n'),
(191, 'spa', 'Deal', 7, 'conditions', '<p>\r\n	Promocion valida de Lunes a Jueves.</p>\r\n'),
(192, 'eng', 'Deal', 7, 'name', 'Ajiaco'),
(193, 'eng', 'Deal', 7, 'description', '<p>\r\n	Autentico Ajiaco Bogotano, acompa&ntilde;ado de arroz, aguacate y mazorca. Disfruta de este delicioso plato en el sur de la ciudad</p>\r\n'),
(194, 'eng', 'Deal', 7, 'conditions', '<p>\r\n	Promocion valida de Lunes a Jueves.</p>\r\n'),
(195, 'spa', 'Deal', 8, 'name', 'Patacones con Carne'),
(196, 'spa', 'Deal', 8, 'description', '<p>\r\n	Patacones con carne acompa&ntilde;ado con jugo de Lulo</p>\r\n'),
(197, 'spa', 'Deal', 8, 'conditions', '<p>\r\n	Promocion valida todos los dias en los horarios de atencion del restaurante</p>\r\n'),
(198, 'eng', 'Deal', 8, 'name', 'Patacones con Carne'),
(199, 'eng', 'Deal', 8, 'description', '<p>\r\n	Patacones con carne acompa&ntilde;ado con jugo de Lulo</p>\r\n'),
(200, 'eng', 'Deal', 8, 'conditions', '<p>\r\n	Promocion valida todos los dias en los horarios de atencion del restaurante</p>\r\n'),
(201, 'spa', 'Zone', 11, 'name', 'Santa Rita'),
(202, 'eng', 'Zone', 11, 'name', 'Santa Rita'),
(203, 'spa', 'Zone', 12, 'name', 'Chapinero'),
(204, 'eng', 'Zone', 12, 'name', 'Chapinero'),
(205, 'spa', 'Deal', 9, 'name', 'prueba'),
(206, 'spa', 'Deal', 9, 'description', '<p>\r\n	asdfasdfasdf</p>\r\n'),
(207, 'spa', 'Deal', 10, 'name', 'otra prueba'),
(208, 'spa', 'Deal', 10, 'description', '<p>\r\n	asdfasdfasdf</p>\r\n'),
(209, 'spa', 'Deal', 11, 'name', 'prueba fecha'),
(210, 'spa', 'Deal', 11, 'description', '<p>\r\n	la descripcion</p>\r\n');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `address_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '1',
  `note` text NOT NULL,
  `rejection_note` text,
  `deal_id` int(11) NOT NULL,
  `is_viewed` tinyint(1) NOT NULL DEFAULT '0',
  `is_approved` tinyint(1) NOT NULL DEFAULT '0',
  `is_paid_with_cash` tinyint(1) NOT NULL DEFAULT '1',
  `order_state_id` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_UNIQUE` (`code`),
  KEY `fk_orders_users_INDEX` (`user_id`),
  KEY `fk_orders_deals_INDEX` (`deal_id`),
  KEY `fk_orders_address_INDEX` (`address_id`),
  KEY `fk_orders_order_states_INDEX` (`order_state_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- Volcado de datos para la tabla `orders`
--

INSERT INTO `orders` (`id`, `code`, `user_id`, `address_id`, `quantity`, `note`, `rejection_note`, `deal_id`, `is_viewed`, `is_approved`, `is_paid_with_cash`, `order_state_id`, `created`, `updated`) VALUES
(1, '1000001', 27, 15, 1, '', NULL, 2, 0, 0, 1, 1, '2012-05-02 09:52:59', '2012-05-02 09:52:59'),
(2, '1000002', 28, 16, 1, '', NULL, 3, 0, 0, 1, 1, '2012-05-06 14:14:15', '2012-05-06 14:14:15'),
(3, '1000003', 28, 16, 1, '', NULL, 3, 1, 1, 1, 2, '2012-05-06 14:14:25', '2012-05-23 10:14:59'),
(4, '1000004', 28, 16, 1, '', NULL, 2, 0, 0, 1, 1, '2012-05-23 10:33:16', '2012-05-23 10:33:16'),
(5, '1000005', 28, 16, 1, '', NULL, 2, 0, 0, 1, 1, '2012-05-23 10:34:19', '2012-05-23 10:34:19'),
(6, '1000006', 28, 16, 1, '', NULL, 2, 0, 0, 1, 1, '2012-05-23 10:35:55', '2012-05-23 10:35:55'),
(7, '1000007', 28, 16, 1, '', NULL, 1, 0, 0, 1, 1, '2012-05-23 10:37:56', '2012-05-23 10:37:56'),
(8, '1000008', 1, 23, 1, '', NULL, 1, 0, 0, 1, 1, '2012-05-23 11:09:14', '2012-05-23 11:09:14'),
(9, '1000009', 1, 24, 1, '', 'pruba anti sql injection', 1, 0, 0, 1, 3, '2012-05-23 11:13:42', '2012-05-23 11:13:42'),
(11, '1000011', 38, 25, 1, '', 'no cubrimos su Ã¡rea de pedidos', 1, 0, 0, 1, 3, '2012-05-29 21:43:43', '2012-05-29 21:43:43'),
(12, '1000012', 1, 23, 1, 'esta es una nota para el domicilio, no CBOLLA POR FAVOR', 'por que me da la gana', 1, 0, 0, 1, 3, '2012-05-31 11:38:48', '2012-05-31 11:38:48'),
(13, '1000013', 1, 23, 1, 'esta es una nota para el domicilio, no CBOLLA POR FAVOR', 'Sin comentarios', 1, 1, 1, 1, 3, '2012-05-31 11:52:10', '2012-05-31 11:52:10'),
(14, '1000014', 1, 23, 1, 'esta es una nota para el domicilio, no CBOLLA POR FAVOR', NULL, 1, 1, 1, 1, 3, '2012-05-31 11:53:14', '2012-05-31 11:53:14'),
(15, '1000015', 1, 23, 1, 'esta es una nota para el domicilio, no CBOLLA POR FAVOR', NULL, 1, 1, 1, 1, 3, '2012-05-31 11:56:36', '2012-05-31 11:56:36'),
(16, '1000016', 1, 23, 1, 'esta es una nota para el domicilio, no CBOLLA POR FAVOR', NULL, 1, 1, 1, 1, 3, '2012-05-31 12:15:58', '2012-05-31 12:15:58'),
(17, '1000017', 1, 23, 1, 'esta es una nota para el domicilio, no CBOLLA POR FAVOR', NULL, 1, 1, 1, 1, 3, '2012-05-31 12:19:11', '2012-05-31 12:19:11'),
(18, '1000018', 1, 23, 1, 'esta es una nota para el domicilio, no CBOLLA POR FAVOR', NULL, 1, 1, 1, 1, 3, '2012-05-31 12:21:30', '2012-05-31 12:21:30'),
(19, '1000019', 1, 23, 1, '', NULL, 2, 0, 0, 1, 1, '2012-05-31 15:42:43', '2012-05-31 15:42:43'),
(20, '1000020', 1, 23, 1, '', NULL, 2, 0, 0, 1, 1, '2012-05-31 15:42:47', '2012-05-31 15:42:47');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `order_states`
--

CREATE TABLE IF NOT EXISTS `order_states` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Volcado de datos para la tabla `order_states`
--

INSERT INTO `order_states` (`id`, `name`) VALUES
(1, 'Pendiente'),
(2, 'Despachada'),
(3, 'Rechazada'),
(4, 'Entregada'),
(5, 'Aprobada');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `keywords` text,
  `active` tinyint(1) DEFAULT NULL,
  `wysiwyg_content` longtext,
  `slug` varchar(100) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title_UNIQUE` (`name`),
  UNIQUE KEY `slug_UNIQUE` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `prizes`
--

CREATE TABLE IF NOT EXISTS `prizes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `description` text,
  `image` varchar(45) DEFAULT NULL,
  `score` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `prizes`
--

INSERT INTO `prizes` (`id`, `name`, `description`, `image`, `score`, `created`, `updated`) VALUES
(1, 'Premio q', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent eleifend fermentum molestie. Praesent rutrum porta nibh, a consectetur quam ullamcorper a. Suspendisse vitae nisl nulla. Curabitur hendrerit feugiat nibh ut pulvinar. Praesent felis lorem, pretium id eleifend ac, consequat in metus. Aenean et ipsum eget nulla malesuada porta. Quisque eu diam molestie magna tincidunt semper nec id elit. Integer quis fermentum nulla. Nulla egestas, lectus id ullamcorper scelerisque, mauris mi dapibus risus, eget ullamcorper enim ante eu eros. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed interdum orci sed felis sagittis pellentesque. Suspendisse at magna sed eros fermentum ornare sed ac urna. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Cras rutrum felis iaculis velit sagittis id dapibus diam congue. Nam vitae magna risus, ac vulputate massa.\r\n', '1.jpg', 55, '2012-03-14 21:58:58', '2012-03-14 21:58:58'),
(2, 'Kit de Cocina', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent eleifend fermentum molestie. Praesent rutrum porta nibh, a consectetur quam ullamcorper a. Suspendisse vitae nisl nulla. Curabitur hendrerit feugiat nibh ut pulvinar. Praesent felis lorem, pretium id eleifend ac, consequat in metus. Aenean et ipsum eget nulla malesuada porta. Quisque eu diam molestie magna tincidunt semper nec id elit. Integer quis fermentum nulla. Nulla egestas, lectus id ullamcorper scelerisque, mauris mi dapibus risus, eget ullamcorper enim ante eu eros. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed interdum orci sed felis sagittis pellentesque. Suspendisse at magna sed eros fermentum ornare sed ac urna. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Cras rutrum felis iaculis velit sagittis id dapibus diam congue. Nam vitae magna risus, ac vulputate massa.\r\n', 'expectativa.jpg', 30, '2012-03-14 21:59:42', '2012-03-14 21:59:42');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `restaurants`
--

CREATE TABLE IF NOT EXISTS `restaurants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) NOT NULL,
  `zone_id` int(11) NOT NULL,
  `code` varchar(20) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `description` text,
  `service_policies` text,
  `schedule` text,
  `image` varchar(255) DEFAULT NULL,
  `lat` varchar(45) NOT NULL,
  `long` varchar(45) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_restaurants_zones_INDEX` (`zone_id`),
  KEY `fk_restaurants_users_INDEX` (`owner_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Volcado de datos para la tabla `restaurants`
--

INSERT INTO `restaurants` (`id`, `owner_id`, `zone_id`, `code`, `name`, `phone`, `address`, `description`, `service_policies`, `schedule`, `image`, `lat`, `long`, `created`, `updated`) VALUES
(1, 23, 1, NULL, 'La Vaca Argentina', '6649734', 'Calle 44N #3E-28 Norte Cali', 'Restaurante Argentino en la zona rosa de la ciudad de Cali.', '', 'De 11 am a 11 pm', '12237_1m (1).jpg', '', '', '2012-04-30 22:11:21', '2012-05-03 11:34:59'),
(2, 24, 2, NULL, 'Picola Italia', '8845214', 'Av. 2BN # 39-112', '', 'Areas de Cobertura: Desde la Cra 5 hasta la calle 100 y desde la Cra. 2 hasta la calle 12', 'Lunes a Viernes de 2 pm a 10 pm', 'logopiccola-italia-793740 (1).jpg', '100', '', '2012-05-01 17:22:07', '2012-05-09 21:49:25'),
(3, 25, 2, NULL, 'La Buena Onda', '8845254', 'calle 8 No. 35-96', '', '', 'Martes a Domingo de 11am a 1 am', 'labuenaonda (1).jpg', '', '', '2012-05-01 18:02:18', '2012-05-03 11:33:07'),
(4, 26, 2, NULL, 'Fast Food', '4587548', 'Calle 44N #3E-28 Norte Cali', '', '', 'Miercoles a Domingo de 1 pm a 11 pm', 'images (1).jpg', '', '', '2012-05-01 18:37:48', '2012-05-03 11:34:34'),
(5, 31, 1, NULL, 'Casa Majagua', '8854745', 'Cra. 10 No. 65-78', '', 'Politicas de Servicio', 'de Lunes a Vienes de 10am a 11pm', '002-MAJAGUA(1) (1).gif', '', '', '2012-05-06 13:42:22', '2012-05-06 13:42:22'),
(6, 32, 2, NULL, 'Los Arrieros del Sur', '8859636', 'Calle 5 No. 36-56', '', '', 'De Martes a Sabado de 10am a 11pm', '333.jpg', '', '', '2012-05-06 14:21:52', '2012-05-06 19:13:15'),
(7, 33, 6, NULL, 'Pataconia', '4456985', 'Av. 2BN # 39-112', '', '', 'De Lunes a Viernes de 10am a 1am', 'pataconia (1).jpg', '', '', '2012-05-06 14:40:03', '2012-05-06 14:46:40');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `restaurants_zones`
--

CREATE TABLE IF NOT EXISTS `restaurants_zones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `restaurant_id` int(11) NOT NULL,
  `zone_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `restaurant_zone` (`restaurant_id`,`zone_id`),
  KEY `fk_restaurants_zones_restaurants_INDEX` (`restaurant_id`),
  KEY `fk_restaurants_zones_zones_INDEX` (`zone_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=35 ;

--
-- Volcado de datos para la tabla `restaurants_zones`
--

INSERT INTO `restaurants_zones` (`id`, `restaurant_id`, `zone_id`) VALUES
(23, 1, 1),
(24, 1, 2),
(27, 2, 1),
(28, 2, 2),
(29, 2, 5),
(30, 2, 6),
(31, 2, 7),
(32, 2, 8),
(33, 2, 9),
(34, 2, 10),
(19, 3, 1),
(20, 3, 2),
(21, 4, 1),
(22, 4, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id`, `name`) VALUES
(1, 'admin'),
(2, 'manager'),
(4, 'owner'),
(3, 'user');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(10) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `role_id` int(11) NOT NULL DEFAULT '2',
  `password` char(40) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `email_verified` tinyint(1) NOT NULL DEFAULT '0',
  `city_id` int(11) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `score` int(11) NOT NULL DEFAULT '0',
  `score_by_invitations` int(11) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  KEY `fk_users_roles_INDEX` (`role_id`),
  KEY `fk_users_cities_INDEX` (`city_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=42 ;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `code`, `email`, `name`, `last_name`, `role_id`, `password`, `active`, `email_verified`, `city_id`, `phone`, `score`, `score_by_invitations`, `created`, `updated`) VALUES
(1, NULL, 'admin@bloomweb.co', 'test', 'admin', 1, '3d66fec9c10dbc7be728b94116fdbad76c134090', 1, 1, NULL, '', 0, 0, NULL, '2012-08-10 13:58:57'),
(23, NULL, 'info@lavacaargentina.com', 'Antonio', 'Aragon', 4, '2e0e8d1f5c63f433d22da2cc8984241afa69fcc1', 1, 1, NULL, NULL, 0, 0, '2012-04-30 22:11:21', '2012-08-10 13:59:22'),
(24, NULL, 'gloria@hotmail.com', 'Gloria', 'Alvarez', 4, '3d66fec9c10dbc7be728b94116fdbad76c134090', 1, 1, NULL, NULL, 0, 0, '2012-05-01 17:22:07', '2012-05-01 17:22:07'),
(25, NULL, 'labuenaonda@hotmail.com', 'Laura', 'Lopez', 4, '3d66fec9c10dbc7be728b94116fdbad76c134090', 1, 1, NULL, NULL, 0, 0, '2012-05-01 18:02:18', '2012-05-01 18:02:18'),
(26, NULL, 'joiss@hotmail.com', 'Jiovanna', 'Alvarez', 4, '3d66fec9c10dbc7be728b94116fdbad76c134090', 1, 1, NULL, NULL, 0, 0, '2012-05-01 18:37:48', '2012-05-01 18:37:48'),
(27, NULL, 'mischa.d.meier@gmail.com', 'Mischa', 'Meier', 3, '82e9913cac39a257a9cc7d0284a832f09cc7220d', 1, 1, 1, '41792577444', 2, 0, '2012-05-02 09:50:28', '2012-05-02 09:50:28'),
(28, NULL, 'joissflaca@hotmail.com', 'Jiovana', 'Alvarez', 3, 'a5fc6d9fcc2640edcce181c66ec3e13e2068e070', 1, 1, 1, '6649734', 28, 0, '2012-05-02 21:23:26', '2012-05-02 21:23:26'),
(29, NULL, 'enfocreativo@hotmail.com', 'Diana Lorena', 'Henao Ortiz', 3, 'fcc9017c0f62d4437cb6c609373ab738645e00a6', 1, 1, 1, '4875959', 8, 0, '2012-05-05 14:36:27', '2012-05-05 14:36:27'),
(30, NULL, 'jiovanna_alvarez@yahoo.es', 'Jhoanna', 'Alvarez', 3, 'a5fc6d9fcc2640edcce181c66ec3e13e2068e070', 1, 1, 1, '8841141', 4, 0, '2012-05-05 14:44:06', '2012-05-05 14:44:06'),
(31, NULL, 'carmenlopera@hotmail.com', 'Carmen', 'Lopera', 4, '3d66fec9c10dbc7be728b94116fdbad76c134090', 1, 1, NULL, NULL, 0, 0, '2012-05-06 13:42:22', '2012-05-06 13:42:22'),
(32, NULL, 'losarrierosdelsur@hotmail.com', 'Lorena', 'Henao', 4, '3d66fec9c10dbc7be728b94116fdbad76c134090', 1, 1, NULL, NULL, 0, 0, '2012-05-06 14:21:52', '2012-05-06 14:21:52'),
(33, NULL, 'pataconia@yahoo.es', 'Luisa ', 'Gonzalez', 4, '3d66fec9c10dbc7be728b94116fdbad76c134090', 1, 1, NULL, NULL, 0, 0, '2012-05-06 14:40:03', '2012-05-06 14:40:03'),
(34, NULL, 'anigonzalez07@gmail.com', 'ana maria', 'agredo gonzalez', 3, 'fcd20718b21acb8f84126fed6c24da75ec736736', 1, 1, 1, '8921655', 2, 0, '2012-05-20 15:46:54', '2012-05-20 15:46:54'),
(35, NULL, 'camer1999@hotmail.com', 'Carolina', 'JimÃ©nez', 3, '85af74dee3aafbeaf7c4b24a21c752bd49c89cfe', 1, 1, 1, '313237574', 2, 0, '2012-05-20 16:48:56', '2012-05-20 16:48:56'),
(36, NULL, 'gommalu@gmail.com', 'Maria Luisa ', 'Gomez', 3, '2d6c15df2a40edbca149ec23c8da8c6e5784c0f7', 1, 1, 2, '3103911454', 2, 0, '2012-05-20 17:23:01', '2012-05-20 17:23:01'),
(37, NULL, 'jiovanna.silicon@gmail.com', 'Jiovanna', 'Alvarez', 3, 'a5fc6d9fcc2640edcce181c66ec3e13e2068e070', 1, 1, 1, '6649734', 500, 0, '2012-05-23 10:54:39', '2012-05-23 10:54:39'),
(38, NULL, 'ricardopandales@gmail.com', 'Ricardo', 'Pandales', 3, '11d505665c18b292627cef59da1d980a4c5d0392', 1, 1, 1, '5555555', 0, 0, '2012-05-29 20:27:58', '2012-05-29 20:27:58'),
(41, NULL, 'dominguez48@hotmail.com', 'Julio', 'DomÃ­nguez', 3, '9dd8c03977080352613aaab619713a2d244866f6', 1, 1, 1, '3764882', 0, 0, '2012-07-09 01:08:33', '2012-07-09 01:08:33');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zones`
--

CREATE TABLE IF NOT EXISTS `zones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `city_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL,
  `lat` varchar(45) DEFAULT NULL,
  `long` varchar(45) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_zones_cities_INDEX` (`city_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Volcado de datos para la tabla `zones`
--

INSERT INTO `zones` (`id`, `city_id`, `name`, `description`, `image`, `lat`, `long`, `created`, `updated`) VALUES
(1, 1, 'Granada', 'Barrio Granada', 'colombia-cali-granada.jpg', NULL, NULL, '2012-02-24 14:25:25', '2012-02-24 14:25:25'),
(2, 1, 'San Antonio', 'Barrio San Antonio', 'colombia-cali-san_antonio.jpg', NULL, NULL, '2012-02-24 14:26:32', '2012-02-24 14:26:32'),
(3, 2, 'Parque de la 93', 'Zona de rumba y restaurantes', 'colombia-bogota-parque93.jpg', NULL, NULL, '2012-02-25 01:09:40', '2012-02-25 01:09:40'),
(4, 2, 'La Macarena', 'Una de las zonas mÃ¡s bohemias de BogotÃ¡, allÃ­ estÃ¡n ubicados varios restaurantes de comida internacional con gran tradiciÃ³n en la ciudad, que permiten disfrutar de momentos agradables en compaÃ±Ã­a de su pareja, amigos o familiares.', 'colombia-bogota-macarena.jpg', NULL, NULL, '2012-02-27 15:52:06', '2012-02-27 15:52:06'),
(5, 1, 'Alamos', NULL, NULL, NULL, NULL, '2012-05-05 14:36:28', '2012-05-05 14:36:28'),
(6, 1, 'Vipasa', NULL, NULL, NULL, NULL, '2012-05-05 14:44:07', '2012-05-05 14:44:07'),
(7, 1, 'Alamos', '', '', NULL, NULL, '2012-05-06 13:12:11', '2012-05-06 13:12:11'),
(8, 1, 'Vipasa', '', '', NULL, NULL, '2012-05-06 13:12:48', '2012-05-06 13:12:48'),
(9, 1, 'La Merced', '', '', NULL, NULL, '2012-05-06 13:13:12', '2012-05-06 13:13:12'),
(10, 1, 'La Flora', '', '', NULL, NULL, '2012-05-06 13:13:30', '2012-05-06 13:13:30'),
(11, 1, 'Santa Rita', NULL, NULL, NULL, NULL, '2012-05-20 15:46:55', '2012-05-20 15:46:55'),
(12, 2, 'Chapinero', NULL, NULL, NULL, NULL, '2012-05-20 17:23:01', '2012-05-20 17:23:01');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
